"""
    Class to create a cayenneLPP byte stream
"""
from .simplecayennelpp import CayenneLPP
